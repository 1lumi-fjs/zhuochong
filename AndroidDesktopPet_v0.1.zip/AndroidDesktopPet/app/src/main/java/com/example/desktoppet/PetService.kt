package com.example.desktoppet
import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.Toast
import androidx.core.app.NotificationCompat

class PetService: Service(){
 lateinit var wm:WindowManager; var v:PetView?=null; var p:WindowManager.LayoutParams?=null
 override fun onCreate(){super.onCreate();startForeground(9,note());if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"请先授予悬浮窗权限",Toast.LENGTH_LONG).show();stopSelf();return}
  wm=getSystemService(WINDOW_SERVICE) as WindowManager;v=PetView(this);p=WindowManager.LayoutParams(280,340,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=80;y=300};wm.addView(v,p);v!!.move={dx,dy->p?.let{it.x+=dx;it.y+=dy;wm.updateViewLayout(v,it)}}
 }
 fun note():Notification{val id="pet";val n=getSystemService(NOTIFICATION_SERVICE) as NotificationManager;if(android.os.Build.VERSION.SDK_INT>=26)n.createNotificationChannel(NotificationChannel(id,"露米桌宠",NotificationManager.IMPORTANCE_LOW));return NotificationCompat.Builder(this,id).setContentTitle("露米桌宠运行中").setContentText("悬浮窗桌宠服务").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build()}
 override fun onDestroy(){v?.let{wm.removeView(it)};v=null;super.onDestroy()};override fun onBind(i:Intent?):IBinder?=null
}
