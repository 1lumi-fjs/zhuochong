package com.example.desktoppet
import android.content.Context
import android.graphics.*
import android.view.*
import android.widget.Toast
import kotlin.math.sin

class PetView(c:Context):View(c){var move:((Int,Int)->Unit)?=null;var lx=0f;var ly=0f;var drag=false;var t=0f;val q=Paint(1)
 override fun onDraw(c:Canvas){t+=.05f;val bob=sin(t.toDouble()).toFloat()*4;val x=width/2f;val y=height/2f+bob
  q.color=Color.argb(45,0,0,0);c.drawOval(x-65,y+130,x+65,y+148,q)
  q.color=Color.rgb(232,235,245);c.drawOval(x-88,y-112,x+88,y+108,q);c.drawRoundRect(x-78,y-10,x-36,y+154,28f,28f,q);c.drawRoundRect(x+36,y-10,x+78,y+154,28f,28f,q)
  q.color=Color.rgb(205,201,230);var h=Path();h.moveTo(x-52,y-84);h.quadTo(x-82,y-138,x-36,y-110);h.close();c.drawPath(h,q);h=Path();h.moveTo(x+52,y-84);h.quadTo(x+82,y-138,x+36,y-110);h.close();c.drawPath(h,q)
  q.color=Color.rgb(255,244,238);c.drawOval(x-58,y-75,x+58,y+48,q)
  q.color=Color.rgb(245,222,230);var e=Path();e.moveTo(x-52,y-42);e.lineTo(x-112,y-72);e.lineTo(x-64,y+4);e.close();c.drawPath(e,q);e=Path();e.moveTo(x+52,y-42);e.lineTo(x+112,y-72);e.lineTo(x+64,y+4);e.close();c.drawPath(e,q)
  q.color=Color.rgb(160,140,215);c.drawOval(x-38,y-20,x-12,y+15,q);c.drawOval(x+12,y-20,x+38,y+15,q);q.color=Color.WHITE;c.drawCircle(x-26,y-9,5f,q);c.drawCircle(x+24,y-9,5f,q)
  q.color=Color.rgb(248,248,252);val d=Path();d.moveTo(x-48,y+38);d.lineTo(x+48,y+38);d.lineTo(x+86,y+148);d.lineTo(x-86,y+148);d.close();c.drawPath(d,q)
  q.color=Color.rgb(185,180,205);q.style=Paint.Style.STROKE;q.strokeWidth=4f;c.drawArc(x-45,y+65,x+45,y+135,0f,180f,false,q);q.style=Paint.Style.FILL
  q.color=Color.rgb(225,220,240);q.style=Paint.Style.STROKE;q.strokeWidth=8f;val tail=Path();tail.moveTo(x+62,y+82);tail.cubicTo(x+130,y+65,x+132,y+135,x+92,y+130);c.drawPath(tail,q);q.style=Paint.Style.FILL
 }
 override fun onTouchEvent(e:MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN-> {lx=e.rawX;ly=e.rawY;drag=false};MotionEvent.ACTION_MOVE->{val dx=(e.rawX-lx).toInt();val dy=(e.rawY-ly).toInt();if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>2)drag=true;if(drag)move?.invoke(dx,dy);lx=e.rawX;ly=e.rawY};MotionEvent.ACTION_UP->{if(!drag)Toast.makeText(context,"你好呀～我是露米！",Toast.LENGTH_SHORT).show()}};return true}
}
