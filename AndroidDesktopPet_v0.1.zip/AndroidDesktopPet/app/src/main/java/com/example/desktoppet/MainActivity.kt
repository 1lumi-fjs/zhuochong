package com.example.desktoppet
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity: AppCompatActivity(){
 override fun onCreate(b: Bundle?){super.onCreate(b)
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,48,32,32)}
  box.addView(TextView(this).apply{text="露米桌宠 · Android 原型";textSize=24f})
  box.addView(TextView(this).apply{text="银白长发、淡紫眼睛、尖耳、双角、白色服装。可悬浮、拖动、点击互动。\n\n第一次使用请先授权悬浮窗。";textSize=16f;setPadding(0,24,0,24)})
  box.addView(Button(this).apply{text="① 授权悬浮窗";setOnClickListener{startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}})
  box.addView(Button(this).apply{text="② 启动露米";setOnClickListener{ContextCompat.startForegroundService(this@MainActivity,Intent(this@MainActivity,PetService::class.java))}})
  box.addView(Button(this).apply{text="停止桌宠";setOnClickListener{stopService(Intent(this@MainActivity,PetService::class.java))}})
  setContentView(box)
 }
}
